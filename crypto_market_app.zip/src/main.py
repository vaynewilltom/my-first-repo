import tkinter as tk
from src.gui.main_window import MainWindow
from src.scraper.market_scraper import MarketScraper
from src.storage.data_store import DataStore
from src.visualization.chart import ChartWindow

def main():
    root = tk.Tk()
    data_store = DataStore()
    scraper = MarketScraper()
    app = MainWindow(root, scraper, data_store)
    root.mainloop()

if __name__ == "__main__":
    main()
